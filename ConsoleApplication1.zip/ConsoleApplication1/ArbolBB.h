#ifndef ARBOLBB_H
#define ARBOLBB_H

#include "NodoArbolBB.h"

template <typename T, typename U, typename V>
class ArbolBB {
private:
    NodoArbol<T, U, V>* raiz;

public:
    ArbolBB();

    void insertar(T nombre, U edad, V carrera);

    bool buscar(T nombre);

    void recorridoEnOrden();

    void recorridoPreOrden();

    void recorridoPostOrden();

    NodoArbol<T, U, V>* obtenerMinimo();

    NodoArbol<T, U, V>* obtenerMaximo();

    void eliminar(T nombre);

    bool estaVacio();

    void limpiar();

private:
    void insertarRecursivo(NodoArbol<T, U, V>*& nodo, NodoArbol<T, U, V>* nuevoNodo);

    bool buscarRecursivo(NodoArbol<T, U, V>* nodo, T nombre);

    void recorridoEnOrdenRecursivo(NodoArbol<T, U, V>* nodo);

    void recorridoPreOrdenRecursivo(NodoArbol<T, U, V>* nodo);

    void recorridoPostOrdenRecursivo(NodoArbol<T, U, V>* nodo);

    NodoArbol<T, U, V>* obtenerMinimoRecursivo(NodoArbol<T, U, V>* nodo);

    NodoArbol<T, U, V>* obtenerMaximoRecursivo(NodoArbol<T, U, V>* nodo);

    NodoArbol<T, U, V>* eliminarRecursivo(NodoArbol<T, U, V>* nodo, T nombre);

    void limpiarRecursivo(NodoArbol<T, U, V>* nodo);
};

template <typename T, typename U, typename V>
ArbolBB<T, U, V>::ArbolBB() {
    raiz = nullptr;
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::insertar(T nombre, U edad, V carrera) {
    NodoArbol<T, U, V>* nuevoNodo = new NodoArbol<T, U, V>(nombre, edad, carrera);
    insertarRecursivo(raiz, nuevoNodo);
}

template <typename T, typename U, typename V>
bool ArbolBB<T, U, V>::buscar(T nombre) {
    return buscarRecursivo(raiz, nombre);
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::recorridoEnOrden() {
    recorridoEnOrdenRecursivo(raiz);
    std::cout << std::endl;
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::recorridoPreOrden() {
    recorridoPreOrdenRecursivo(raiz);
    std::cout << std::endl;
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::recorridoPostOrden() {
    recorridoPostOrdenRecursivo(raiz);
    std::cout << std::endl;
}

template <typename T, typename U, typename V>
NodoArbol<T, U, V>* ArbolBB<T, U, V>::obtenerMinimo() {
    return obtenerMinimoRecursivo(raiz);
}

template <typename T, typename U, typename V>
NodoArbol<T, U, V>* ArbolBB<T, U, V>::obtenerMaximo() {
    return obtenerMaximoRecursivo(raiz);
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::eliminar(T nombre) {
    raiz = eliminarRecursivo(raiz, nombre);
}

template <typename T, typename U, typename V>
bool ArbolBB<T, U, V>::estaVacio() {
    std::cout << "No hay elememnto" << std::endl;
    return raiz == nullptr;
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::limpiar() {
    limpiarRecursivo(raiz);
    raiz = nullptr;
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::insertarRecursivo(NodoArbol<T, U, V>*& nodo, NodoArbol<T, U, V>* nuevoNodo) {
    if (nodo == nullptr) {
        nodo = nuevoNodo;
    }
    else if (nuevoNodo->nombre < nodo->nombre) {
        insertarRecursivo(nodo->izquierdo, nuevoNodo);
    }
    else if (nuevoNodo->nombre > nodo->nombre) {
        insertarRecursivo(nodo->derecho, nuevoNodo);
    }
}

template <typename T, typename U, typename V>
bool ArbolBB<T, U, V>::buscarRecursivo(NodoArbol<T, U, V>* nodo, T nombre) {
    if (nodo == nullptr) {
        std::cout << "El elemento buscado no se encuentra en el arbol" << endl;
        return false;
    }
    else if (nombre == nodo->nombre) {
        return true;
    }
    else if (nombre < nodo->nombre) {
        return buscarRecursivo(nodo->izquierdo, nombre);
    }
    else {
        return buscarRecursivo(nodo->derecho, nombre);
    }
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::recorridoEnOrdenRecursivo(NodoArbol<T, U, V>* nodo) {
    if (nodo != nullptr) {
        recorridoEnOrdenRecursivo(nodo->izquierdo);
        std::cout << nodo->nombre << ", " << nodo->edad << ", " << nodo->carrera << " ";
        recorridoEnOrdenRecursivo(nodo->derecho);
    }
    
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::recorridoPreOrdenRecursivo(NodoArbol<T, U, V>* nodo) {
    if (nodo != nullptr) {
        std::cout << nodo->nombre << ", " << nodo->edad << ", " << nodo->carrera << " ";
        recorridoPreOrdenRecursivo(nodo->izquierdo);
        recorridoPreOrdenRecursivo(nodo->derecho);
    }
  
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::recorridoPostOrdenRecursivo(NodoArbol<T, U, V>* nodo) {
    if (nodo != nullptr) {
        recorridoPostOrdenRecursivo(nodo->izquierdo);
        recorridoPostOrdenRecursivo(nodo->derecho);
        std::cout << nodo->nombre << ", " << nodo->edad << ", " << nodo->carrera << " ";
    }
    
}

template <typename T, typename U, typename V>
NodoArbol<T, U, V>* ArbolBB<T, U, V>::obtenerMinimoRecursivo(NodoArbol<T, U, V>* nodo) {
    if (nodo == nullptr) {
        std::cout << "No hay elementos en el arbol" << std::endl;
        return nullptr;
    }
    else if (nodo->izquierdo == nullptr) {
        return nodo;
    }
    else {
        return obtenerMinimoRecursivo(nodo->izquierdo);
    }
}

template <typename T, typename U, typename V>
NodoArbol<T, U, V>* ArbolBB<T, U, V>::obtenerMaximoRecursivo(NodoArbol<T, U, V>* nodo) {
    if (nodo == nullptr) {
        std::cout << "No hay elementos en el arbol" << endl;
        return nullptr;
    }
    else if (nodo->derecho == nullptr) {
        return nodo;
    }
    else {
        return obtenerMaximoRecursivo(nodo->derecho);
    }
}

template <typename T, typename U, typename V>
NodoArbol<T, U, V>* ArbolBB<T, U, V>::eliminarRecursivo(NodoArbol<T, U, V>* nodo, T nombre) {
    if (nodo == nullptr) {
        std::cout << "No hay elementos en el arbol" << std::endl;
        return nullptr;
    }
    else if (nombre < nodo->nombre) {
        nodo->izquierdo = eliminarRecursivo(nodo->izquierdo, nombre);
    }
    else if (nombre > nodo->nombre) {
        nodo->derecho = eliminarRecursivo(nodo->derecho, nombre);
    }
    else {
        if (nodo->izquierdo == nullptr && nodo->derecho == nullptr) {
            delete nodo;
            nodo = nullptr;
        }
        else if (nodo->izquierdo == nullptr) {
            NodoArbol<T, U, V>* temp = nodo;
            nodo = nodo->derecho;
            delete temp;
        }
        else if (nodo->derecho == nullptr) {
            NodoArbol<T, U, V>* temp = nodo;
            nodo = nodo->izquierdo;
            delete temp;
        }
        else {
            NodoArbol<T, U, V>* minimo = obtenerMinimoRecursivo(nodo->derecho);
            nodo->nombre = minimo->nombre;
            nodo->edad = minimo->edad;
            nodo->carrera = minimo->carrera;
            nodo->derecho = eliminarRecursivo(nodo->derecho, minimo->nombre);
        }
    }
    return nodo;
}

template <typename T, typename U, typename V>
void ArbolBB<T, U, V>::limpiarRecursivo(NodoArbol<T, U, V>* nodo) {
    if (nodo != nullptr) {
        limpiarRecursivo(nodo->izquierdo);
        limpiarRecursivo(nodo->derecho);
        delete nodo;
    }
}

#endif  // ARBOLBB_H
