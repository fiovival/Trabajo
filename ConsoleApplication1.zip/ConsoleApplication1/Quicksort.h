

#include "ListaDobleEnlazada.h"

template<typename T>
Nodo<T>* partition(Nodo<T>* low, Nodo<T>* high) {
    T pivot = high->nombre;
    Nodo<T>* i = low->anterior;

    for (Nodo<T>* j = low; j != high; j = j->siguiente) {
        if (j->nombre <= pivot) {
            i = (i == nullptr) ? low : i->siguiente;
            swap(i->nombre, j->nombre);
            swap(i->edad, j->edad);
            swap(i->carrera, j->carrera);
        }
    }

    i = (i == nullptr) ? low : i->siguiente;
    swap(i->nombre, high->nombre);
    swap(i->edad, high->edad);
    swap(i->carrera, high->carrera);

    return i;
}

template<typename T>
void quicksortUtil(Nodo<T>* low, Nodo<T>* high) {
    if (high != nullptr && low != high && low != high->siguiente) {
        Nodo<T>* pivot = partition(low, high);
        quicksortUtil(low, pivot->anterior);
        quicksortUtil(pivot->siguiente, high);
    }
}

template<typename T>
void quicksort(ListaDoblementeEnlazada<T>& lista) {
    quicksortUtil(lista.cabeza, lista.cola);
}

//#endif  // QUICKSORT_H
