#include "pch.h"
#include "Opciones.h"
#include "ArbolBB.h"

using namespace System;
using namespace std;

void mostrarMenu1();

int main() {
   
    mostrarMenu1();


    return 0;
}
void mostrarMenu1() {
    int opcion;
    char input[256];

    do {
        Console::Clear();
        cout << "INICIO MENU" << endl;
        cout << "Seleccione una opcion:" << endl;
        cout << "1. Ingresar" << endl;
        cout << "2. Crear cuenta" << endl;
        cout << "3. Iniciar sesion" << endl;
        cout << "4. Acerca del programa" << endl;
        cout << "5. Intregrantes " << endl;
        cout << "6. Salir" << endl;
        cout << "Opcion: ";

        // Leer la entrada del usuario como un string
        cin.getline(input, 256);

        // Validar que la entrada sea un n�mero entero
        bool esEntero = true;
        for (int i = 0; i < strlen(input); i++) {
            if (!isdigit(input[i])) {
                esEntero = false;
                break;
            }
        }

        if (esEntero) {
            opcion = stoi(input);
            Opciones* opc;
            switch (opcion) {
                
            case 1:
                Console::Clear();
                cout << "Ha seleccionado Ingresar" << endl;
                opc->opcion1();
               
                break;
            case 2:
                Console::Clear();
                cout << "Ha seleccionado Crear cuenta" << endl;
                // Aqu� ir�a el c�digo para la opci�n Crear cuenta
              
                break;
            case 3:
                Console::Clear();
                cout << "Ha seleccionado Iniciar sesion" << endl;
                //Aqu� ir�a el c�digo para la opci�n Iniciar sesi�n
               
                break;
            case 4:
                cout << "\t\t\tAcerca del programa " << endl;
                break;
            case 5:
                Console::Clear();
                cout << "\t\t\tIntegrantes" << endl;
                //Aqu� ir�a el c�digo para la opci�n Iniciar sesi�n
                break;
            case 6:
                Console::Clear();
                cout << "Salio del sistema, Que tenga un buen dia estimado usuario." << endl;
                //Aqu� ir�a el c�digo para la opci�n Iniciar sesi�n
                break;

            default:
                cout << "Opcion invalida. Intente de nuevo." << endl;
            }
        }
        else {
            cout << "Entrada invalida, recuerde que debe de ser un entero. Intente de nuevo ;)." << endl;
           
        }
        system("pause");

    } while (opcion != 6);
}
