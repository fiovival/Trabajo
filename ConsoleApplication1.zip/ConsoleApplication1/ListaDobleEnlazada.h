#include <iostream>
#include "NodoListaDoble.h"

template <typename T>
class ListaDoblementeEnlazada {
private:
    Nodo<T>* primero;
    Nodo<T>* ultimo;

public:
    ListaDoblementeEnlazada();
    bool estaVacia();
    void insertarAlInicio(T valor);
    void insertarAlFinal(T valor);
    void insertarEnPosicion(T valor, int posicion);
    void eliminarEnPosicion(int posicion);
    void imprimirLista();
    int obtenerTamanio();
    T obtenerPrimero();
    T obtenerUltimo();
    int buscar(T valor);
    T obtenerEnPosicion(int posicion);
    void eliminarPrimero();
    void eliminarUltimo();
    void eliminarValor(T valor);
    void vaciar();
    void ordenarPorNombre() {
        quicksort(*this);
    }
};

template <typename T>
ListaDoblementeEnlazada<T>::ListaDoblementeEnlazada() {
    primero = nullptr;
    ultimo = nullptr;
}

template <typename T>
bool ListaDoblementeEnlazada<T>::estaVacia() {
    return primero == nullptr;
}

template <typename T>
void ListaDoblementeEnlazada<T>::insertarAlInicio(T valor) {
    Nodo<T>* nuevoNodo = new Nodo<T>();
    nuevoNodo->valor = valor;

    if (estaVacia()) {
        primero = nuevoNodo;
        ultimo = nuevoNodo;
    }
    else {
        nuevoNodo->siguiente = primero;
        primero->anterior = nuevoNodo;
        primero = nuevoNodo;
    }
}

template <typename T>
void ListaDoblementeEnlazada<T>::insertarAlFinal(T valor) {
    Nodo<T>* nuevoNodo = new Nodo<T>();
    nuevoNodo->valor = valor;

    if (estaVacia()) {
        primero = nuevoNodo;
        ultimo = nuevoNodo;
    }
    else {
        nuevoNodo->anterior = ultimo;
        ultimo->siguiente = nuevoNodo;
        ultimo = nuevoNodo;
    }
}

template <typename T>
void ListaDoblementeEnlazada<T>::insertarEnPosicion(T valor, int posicion) {
    if (posicion < 0)
        return;

    Nodo<T>* nuevoNodo = new Nodo<T>();
    nuevoNodo->valor = valor;

    if (posicion == 0) {
        nuevoNodo->siguiente = primero;
        primero->anterior = nuevoNodo;
        primero = nuevoNodo;
    }
    else {
        Nodo<T>* actual = primero;
        int indice = 0;

        while (actual != nullptr && indice < posicion - 1) {
            actual = actual->siguiente;
            indice++;
        }

        if (actual == nullptr)
            return;

        nuevoNodo->siguiente = actual->siguiente;
        nuevoNodo->anterior = actual;
        if (actual->siguiente != nullptr)
            actual->siguiente->anterior = nuevoNodo;
        actual->siguiente = nuevoNodo;

        if (actual == ultimo)
            ultimo = nuevoNodo;
    }
}

template <typename T>
void ListaDoblementeEnlazada<T>::eliminarEnPosicion(int posicion) {
    if (estaVacia())
        return;

    if (posicion == 0) {
        Nodo<T>* temp = primero;
        primero = primero->siguiente;
        if (primero != nullptr)
            primero->anterior = nullptr;
        delete temp;

        if (primero == nullptr)
            ultimo = nullptr;
    }
    else {
        Nodo<T>* actual = primero;
        int indice = 0;

        while (actual != nullptr && indice < posicion) {
            actual = actual->siguiente;
            indice++;
        }

        if (actual == nullptr)
            return;

        actual->anterior->siguiente = actual->siguiente;
        if (actual->siguiente != nullptr)
            actual->siguiente->anterior = actual->anterior;

        if (actual == ultimo)
            ultimo = actual->anterior;

        delete actual;
    }
}

template <typename T>
void ListaDoblementeEnlazada<T>::imprimirLista() {
    Nodo<T>* actual = primero;
    while (actual != nullptr) {
        std::cout << actual->valor << " ";
        actual = actual->siguiente;
    }
    std::cout << std::endl;
}

template <typename T>
int ListaDoblementeEnlazada<T>::obtenerTamanio() {
    int tamanio = 0;
    Nodo<T>* actual = primero;
    while (actual != nullptr) {
        tamanio++;
        actual = actual->siguiente;
    }
    return tamanio;
}

template <typename T>
T ListaDoblementeEnlazada<T>::obtenerPrimero() {
    if (estaVacia())
        throw std::runtime_error("La lista est� vac�a");
    return primero->valor;
}

template <typename T>
T ListaDoblementeEnlazada<T>::obtenerUltimo() {
    if (estaVacia())
        throw std::runtime_error("La lista est� vac�a");
    return ultimo->valor;
}

template <typename T>
int ListaDoblementeEnlazada<T>::buscar(T valor) {
    Nodo<T>* actual = primero;
    int posicion = 0;

    while (actual != nullptr) {
        if (actual->valor == valor)
            return posicion;

        actual = actual->siguiente;
        posicion++;
    }

    return -1; // Si no se encuentra el valor
}

template <typename T>
T ListaDoblementeEnlazada<T>::obtenerEnPosicion(int posicion) {
    if (posicion < 0 || posicion >= obtenerTama�o())
        throw std::out_of_range("Posici�n inv�lida");

    Nodo<T>* actual = primero;
    int indice = 0;

    while (actual != nullptr && indice < posicion) {
        actual = actual->siguiente;
        indice++;
    }

    return actual->valor;
}

template <typename T>
void ListaDoblementeEnlazada<T>::eliminarPrimero() {
    if (estaVacia())
        return;

    Nodo<T>* temp = primero;
    primero = primero->siguiente;
    if (primero != nullptr)
        primero->anterior = nullptr;
    delete temp;

    if (primero == nullptr)
        ultimo = nullptr;
}

template <typename T>
void ListaDoblementeEnlazada<T>::eliminarUltimo() {
    if (estaVacia())
        return;

    if (primero == ultimo) {
        delete primero;
        primero = nullptr;
        ultimo = nullptr;
        return;
    }

    Nodo<T>* temp = ultimo->anterior;
    temp->siguiente = nullptr;
    delete ultimo;
    ultimo = temp;
}

template <typename T>
void ListaDoblementeEnlazada<T>::eliminarValor(T valor) {
    Nodo<T>* actual = primero;

    while (actual != nullptr) {
        if (actual->valor == valor) {
            if (actual == primero)
                eliminarPrimero();
            else if (actual == ultimo)
                eliminarUltimo();
            else {
                actual->anterior->siguiente = actual->siguiente;
                actual->siguiente->anterior = actual->anterior;
                delete actual;
            }
            return;
        }

        actual = actual->siguiente;
    }
}

template <typename T>
void ListaDoblementeEnlazada<T>::vaciar() {
    Nodo<T>* actual = primero;

    while (actual != nullptr) {
        Nodo<T>* temp = actual;
        actual = actual->siguiente;
        delete temp;
    }

    primero = nullptr;
    ultimo = nullptr;
}
