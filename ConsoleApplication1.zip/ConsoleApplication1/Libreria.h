#pragma once
#include <iostream>
#include <string>
#include <time.h>
#include <fstream>
using namespace System;
using namespace std;