#pragma once
#include "Libreria.h"
class Opciones {

public:
    
	Opciones(){}
	~Opciones(){}
	void opcion1() {
        int elecion;
        do
        {
            cout << "\t\t\tBIENVENIDO AL SISTEMA DE FACILITO" << endl;
            cout << "Quiere ver..." << endl;
            cout << "1. Combustible" << endl;
            cout << "2. Balones de GAS" << endl;
            cout << "3. Salir" << endl;
            elecion = verifOpcion();
            switch (elecion)
            {
            case 1:
                cout << "Eligio la opcion 1::..." << endl;
                //Codigo de llamada de Combustible
                break;
            case 2:
                cout << "Eligio la opcion 2::..." << endl;
                //Codigo de llamada de Balones de GAS
                break;
            case 3:
                cout << "Saliendo del sistema FACILITO..." << endl;
                break;

            default:
                cout << "La opcion ingresada no esta disponible..." << endl<<endl;
                cout << "Intende nuevamente y recuerde ingresar las opciones disponobles..." << endl;
                break;
            }
            system("pause");
            Console::Clear();
        } while (elecion!=3);

    }
	void opcion2() {
        string correo;

        do
        {
            cout << "Ingrese su correo electronico" << endl;
            cin >> correo;

            if (true)
            {

            }


        } while (true);
    
    }
	void opcion3() {}
	void opcion4() {}
	void opcion5() {}
	int verifOpcion(){

        string entrada;
        int opcion;

        while (true)
        {
            cout << "Ingrese una opcion: ";
            getline(cin, entrada);

            try
            {
                opcion = stoi(entrada);
                break;
            }
            catch (const exception& e)
            {
                cout << "Opcion invalida,. Intente nuevamente." << endl;
                system("pause");
            }
        }

        return opcion;
	}
};