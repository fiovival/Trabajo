#ifndef NODOARBOL_H
#define NODOARBOL_H

template <typename T, typename U, typename V>
class NodoArbol {
public:
    T nombre;
    U edad;
    V carrera;
    NodoArbol<T, U, V>* izquierdo;
    NodoArbol<T, U, V>* derecho;

    NodoArbol(T nombre, U edad, V carrera) {
        this->nombre = nombre;
        this->edad = edad;
        this->carrera = carrera;
        izquierdo = nullptr;
        derecho = nullptr;
    }
};

#endif  // NODOARBOL_H
