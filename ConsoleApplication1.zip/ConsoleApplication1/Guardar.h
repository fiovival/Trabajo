/*#include <iostream>
#include <fstream>
#include "ListaDoblementeEnlazada.h"
using namespace std;

struct Persona {
    string nombre;
    int edad;
    string carrera;
};

int main() {
    ListaDoblementeEnlazada<Persona> lista;

    // Insertar elementos en la lista
    Persona persona1{ "Juan", 25, "Ingenier�a" };
    Persona persona2{ "Mar�a", 30, "Medicina" };
    Persona persona3{ "Carlos", 28, "Arquitectura" };

    lista.insertarAlInicio(persona1.nombre, persona1.edad, persona1.carrera);
    lista.insertarAlFinal(persona2.nombre, persona2.edad, persona2.carrera);
    lista.insertarAlFinal(persona3.nombre, persona3.edad, persona3.carrera);

    // Imprimir la lista antes de ordenar
    cout << "Elementos de la lista antes de ordenar:" << endl;
    lista.imprimir();

    // Ordenar la lista por nombre
    lista.ordenarPorNombre();

    // Imprimir la lista despu�s de ordenar
    cout << "Elementos de la lista despu�s de ordenar:" << endl;
    lista.imprimir();

    // Guardar elementos en un archivo
    ofstream archivo("elementos.txt");
    if (archivo.is_open()) {
        Nodo<Persona>* nodoActual = lista.cabeza;
        while (nodoActual != nullptr) {
            archivo << nodoActual->dato.nombre << ";" << nodoActual->dato.edad << ";" << nodoActual->dato.carrera << "\n";
            nodoActual = nodoActual->siguiente;
        }
        archivo.close();
        cout << "Elementos guardados en el archivo 'elementos.txt'" << endl;
    }
    else {
        cout << "No se pudo abrir el archivo" << endl;
    }

    return 0;
}*/